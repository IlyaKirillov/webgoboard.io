"use strict";
/**
 * User: Ilja.Kirillov
 * Date: 26.09.14
 * Time: 17:40
 */

var EGameListRecord =
{
    Id        : 1,
    Type      : 2,
    WRank     : 3,
    WName     : 4,
    Vs        : 5,
    BRank     : 6,
    BName     : 7,
    Observers : 8,
    Move      : 9,
    Info      : 10
};

var g_oGamesList =
{
    Headers :
    {
        Sizes : [0, 55, 70, 110, 250, 275, 315, 440, 500, 550],
        Count : 10,
        1  : "Id",
        2  : "Kind",
        3  : "wr",
        4  : "White",
        5  : "",
        6  : "br",
        7  : "Black",
        8  : "Observers",
        9  : "Move",
        10 : "Comment"
    },

    SortType : -EGameListRecord.WRank,

    Set_SortType : function(nColNum, Direction)
    {
        if (Direction > 0)
            g_oGamesList.SortType = nColNum + 1;
        else
            g_oGamesList.SortType = -(nColNum + 1);
    },

    SortFunction : function (oRecord1, oRecord2)
    {
        if ("" === oRecord1.m_sGameInfo && "" !== oRecord2.m_sGameInfo)
            return -1;
        else if ("" !== oRecord1.m_sGameInfo && "" === oRecord2.m_sGameInfo)
            return 1;

        var SortType = g_oGamesList.SortType;
        if (EGameListRecord.Id === SortType)
        {
            if (oRecord1.m_nGameId < oRecord2.m_nGameId)
                return -1;
            else if (oRecord1.m_nGameId > oRecord2.m_nGameId)
                return 1;
        }
        else if (-EGameListRecord.Id === SortType)
        {
            if (oRecord1.m_nGameId < oRecord2.m_nGameId)
                return 1;
            else if (oRecord1.m_nGameId > oRecord2.m_nGameId)
                return -1;
        }
        else if (EGameListRecord.WRank === SortType)
        {
            var nRes = g_oGamesList.private_SortByInfoState(oRecord1, oRecord2);
            if (0 !== nRes)
                return nRes;

            if (oRecord1.m_nWhiteRank < oRecord2.m_nWhiteRank)
                return -1;
            else if (oRecord1.m_nWhiteRank > oRecord2.m_nWhiteRank)
                return 1;

            return g_oGamesList.private_SortByWhiteName(oRecord1, oRecord2);
        }
        else if (-EGameListRecord.WRank === SortType)
        {
            var nRes = g_oGamesList.private_SortByInfoState(oRecord1, oRecord2);
            if (0 !== nRes)
                return nRes;

            if (oRecord1.m_nWhiteRank < oRecord2.m_nWhiteRank)
                return 1;
            else if (oRecord1.m_nWhiteRank > oRecord2.m_nWhiteRank)
                return -1;

            return g_oGamesList.private_SortByWhiteName(oRecord1, oRecord2);
        }
        else if (EGameListRecord.WName === SortType)
        {
            if (oRecord1.m_sWhiteName < oRecord2.m_sWhiteName)
                return -1;
            else if (oRecord1.m_sWhiteName > oRecord2.m_sWhiteName)
                return 1;
        }
        else if (-EGameListRecord.WName === SortType)
        {
            if (oRecord1.m_sWhiteName < oRecord2.m_sWhiteName)
                return 1;
            else if (oRecord1.m_sWhiteName > oRecord2.m_sWhiteName)
                return -1;
        }
        else if (EGameListRecord.BRank === SortType)
        {
            var nRes = g_oGamesList.private_SortByInfoState(oRecord1, oRecord2);
            if (0 !== nRes)
                return nRes;

            if (oRecord1.m_nBlackRank < oRecord2.m_nBlackRank)
                return -1;
            else if (oRecord1.m_nBlackRank > oRecord2.m_nBlackRank)
                return 1;

            return g_oGamesList.private_SortByBlackName(oRecord1, oRecord2);
        }
        else if (-EGameListRecord.BRank === SortType)
        {
            var nRes = g_oGamesList.private_SortByInfoState(oRecord1, oRecord2);
            if (0 !== nRes)
                return nRes;

            if (oRecord1.m_nBlackRank < oRecord2.m_nBlackRank)
                return 1;
            else if (oRecord1.m_nBlackRank > oRecord2.m_nBlackRank)
                return -1;

            return g_oGamesList.private_SortByBlackName(oRecord1, oRecord2);
        }
        else if (EGameListRecord.BName === SortType)
        {
            if (oRecord1.m_sBlackName < oRecord2.m_sBlackName)
                return -1;
            else if (oRecord1.m_sBlackName > oRecord2.m_sBlackName)
                return 1;
        }
        else if (-EGameListRecord.BName === SortType)
        {
            if (oRecord1.m_sBlackName < oRecord2.m_sBlackName)
                return 1;
            else if (oRecord1.m_sBlackName > oRecord2.m_sBlackName)
                return -1;
        }
        else if (EGameListRecord.Observers === SortType)
        {
            if (oRecord1.m_nObserversCount < oRecord2.m_nObserversCount)
                return -1;
            else if (oRecord1.m_nObserversCount > oRecord2.m_nObserversCount)
                return 1;
        }
        else if (-EGameListRecord.Observers === SortType)
        {
            if (oRecord1.m_nObserversCount < oRecord2.m_nObserversCount)
                return 1;
            else if (oRecord1.m_nObserversCount > oRecord2.m_nObserversCount)
                return -1;
        }

        return 0;
    },

    private_SortByInfoState : function(oRecord1, oRecord2)
    {
        if (0x50 === oRecord1.m_nGameInfo && 0x50 !== oRecord2.m_nGameInfo)
            return -1;

        if (0x50 !== oRecord1.m_nGameInfo && 0x50 === oRecord2.m_nGameInfo)
            return 1;

        if (4 !== (oRecord1.m_nState & 0xFF) && 4 === (oRecord2.m_nState & 0xFF))
            return -1;

        if (4 === (oRecord1.m_nState & 0xFF) && 4 !== (oRecord2.m_nState & 0xFF))
            return 1;

        return 0;
    },

    private_SortByWhiteName : function(oRecord1, oRecord2)
    {
        if (oRecord1.m_sWhiteName < oRecord2.m_sWhiteName)
            return -1;
        else if (oRecord1.m_sWhiteName > oRecord2.m_sWhiteName)
            return 1;

        return 0;
    },

    private_SortByBlackName : function(oRecord1, oRecord2)
    {
        if (oRecord1.m_sBlackName < oRecord2.m_sBlackName)
            return -1;
        else if (oRecord1.m_sBlackName > oRecord2.m_sBlackName)
            return 1;

        return 0;
    },

    Is_Sortable : function (nColNum)
    {
        var eType = nColNum + 1;
        switch (eType)
        {
            case EGameListRecord.Id       :
            case EGameListRecord.WRank    :
            case EGameListRecord.WName    :
            case EGameListRecord.BRank    :
            case EGameListRecord.BName    :
            case EGameListRecord.Observers:
                return true;
        }

        return false;
    },

    Draw_Header : function(dX, dY, oContext, nColNum)
    {
        var eType = nColNum + 1;
        var SortType = g_oGamesList.SortType;

        var sHeaderText;
        if (eType === SortType)
            sHeaderText = g_oGamesList.Headers[eType] + String.fromCharCode(0x25B2);
        else if (eType === -SortType)
            sHeaderText = g_oGamesList.Headers[eType] + String.fromCharCode(0x25BC);
        else
            sHeaderText = g_oGamesList.Headers[eType];

        oContext.fillStyle = "#000000";
        oContext.fillText(sHeaderText, dX, dY);
    },

    Draw_Record : function(dX, dY, oContext, oRecord, nColNum)
    {
        var eType = nColNum + 1;
        oRecord.Draw(oContext, dX, dY, eType);
    },

    Get_Record : function(aLine)
    {
        var nGameId         = aLine[1] | 0;
        var nGameInfo       = aLine[2] | 0;
        var nObserversCount = aLine[3] | 0;
        var sWhite          = aLine[5];
        var nWhiteRank      = aLine[6] | 0;
        var sBlack          = aLine[8];
        var nBlackRank      = aLine[9] | 0;
        var sGameInfo       = aLine[10];
        var nMoveNumber     = aLine[11] | 0;

        return new CGameListRecord(nGameId, sWhite, nWhiteRank, sBlack, nBlackRank, nObserversCount, sGameInfo, nMoveNumber);
    },

    Get_Key : function(aLine)
    {
        return (aLine[1] | 0);
    },

    Handle_DoubleClick : function(Record)
    {
        EnterGameRoom(Record.m_nGameId);
    }
};

function CGameListRecord(nGameId, sWhite, nWhite, sBlack, nBlack, nObservers, sGameInfo, nMoveNumber)
{
    this.m_nGameId         = nGameId;
    this.m_nObserversCount = nObservers;
    this.m_sWhiteName      = sWhite;
    this.m_nWhiteRank      = nWhite;
    this.m_sBlackName      = sBlack;
    this.m_nBlackRank      = nBlack;
    this.m_sGameInfo       = sGameInfo;
    this.m_nMove           = nMoveNumber;
}

CGameListRecord.prototype.Draw = function(oContext, dX, dY, eType)
{
    if ("" !== this.m_sGameInfo) // законченная игра
        oContext.fillStyle = "#CCCCCC";
    else
        oContext.fillStyle = "#000000";

    var sString = "";
    switch(eType)
    {
        case EGameListRecord.Id       : sString += this.m_nGameId; break;
        case EGameListRecord.Type     : sString += ""; break;
        case EGameListRecord.WRank    : sString += "[" + this.private_GetRank(this.m_nWhiteRank) + "]"; break;
        case EGameListRecord.WName    : sString += this.m_sWhiteName; break;
        case EGameListRecord.Vs       : sString += "vs."; break;
        case EGameListRecord.BRank    : sString += "[" + this.private_GetRank(this.m_nBlackRank) + "]"; break;
        case EGameListRecord.BName    : sString += this.m_sBlackName; break;
        case EGameListRecord.Observers: sString += this.m_nObserversCount; break;
        case EGameListRecord.Move     : sString += "" + this.m_nMove; break;
        case EGameListRecord.Info     : sString += this.m_sGameInfo; break;
    }

    oContext.fillText(sString, dX, dY);
};

CGameListRecord.prototype.Compare = function(sKey)
{
    if (this.m_nGameId === sKey)
        return true;

    return false;
};

CGameListRecord.prototype.Get_Key = function()
{
    return this.m_nGameId;
};

CGameListRecord.prototype.Update = function(aLine)
{
    this.m_sWhiteName = aLine[5];
    this.m_nWhiteRank = aLine[6] | 0;
    this.m_sBlackName = aLine[8];
    this.m_nBlackRank = aLine[9] | 0;
    this.m_sGameInfo  = aLine[10];
    this.m_nMove      = aLine[11] | 0;
};

CGameListRecord.prototype.private_GetRank = function(nRank)
{
    if (nRank <= -2)
        return "?";
    else if (nRank === -1)
        return "-";
    else if (nRank <= 29)
        return (30 - nRank) + "k";
    else if (nRank <= 49)
        return (nRank - 29) + "d";
    else
        return (nRank - 49) + "p";
};

CGameListRecord.prototype.private_GetType = function(nType)
{
    return String.fromCharCode(nType);
};

CGameListRecord.prototype.private_GetState = function(nState)
{
    var nSubType = nState & 0xFF;
    var nType    = (nState >> 8) & 0xFF;

    if (1 == nType)
    {
        switch(nSubType)
        {
            case 0x1: return "Early";
            case 0x2: return "Middle";
            case 0x3: return "Final";
            case 0x4: return "End";
            case 0x5: return "Review";
            case 0x6: return "Stop";
            case 0xb: return "1s";
            case 0xc: return "2s";
            case 0xd: return "3s";
            case 0xe: return "4s";
        }
    }

    return "";
};