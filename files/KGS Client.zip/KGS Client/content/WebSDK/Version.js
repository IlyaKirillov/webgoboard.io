/**
 * Copyright 2015 the HtmlGoBoard project authors.
 * All rights reserved.
 * Project  WebSDK
 * Author   Ilya Kirillov
 * Date     29.03.15
 * Time     3:08
 */

CGoBoardApi.prototype.Version = "0.10.6";
